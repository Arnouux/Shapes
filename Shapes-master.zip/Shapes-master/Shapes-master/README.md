# Shapes

Todo :

- [ ] Menu Création -> Panel
- [ ] Ctrl + Z
- [x] Selection de pls forme et les collectionner.
- [ ] Rotation
- [ ] Poser une forme = un son
- [ ] Copié collé
