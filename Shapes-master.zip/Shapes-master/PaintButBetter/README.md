# Shapes

Todo :

- [ ] Menu Création -> Panel
- [x] Ctrl + Z
- [x] Selection de pls forme et les collectionner.
- [ ] Rotation
- [x] Poser une forme = un son
- [ ] Copié collé
