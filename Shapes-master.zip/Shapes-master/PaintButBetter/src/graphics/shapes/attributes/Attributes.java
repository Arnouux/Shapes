package graphics.shapes.attributes;

public abstract class Attributes {
	
	public abstract String getId();
}
