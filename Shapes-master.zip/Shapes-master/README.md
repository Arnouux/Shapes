# Shapes

Todo :

- [x] Menu Création -> Panel -> Update: Un panneau a été ajouté. Fonctionnalité à ajouter. 
- [ ] Ctrl + Z
- [x] Selection de pls forme et les collectionner.
- [ ] Rotation
- [x] Poser une forme = un son
- [ ] Copié collé
